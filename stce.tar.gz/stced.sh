#!/bin/bash

zenity --info --text="Ciao ti ho hackerato! Nome: Paolo Rampino - Data: $(date '+%d-%m-%Y %H:%M')"
